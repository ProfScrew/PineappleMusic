config = {
    'SECRET_KEY' : "0bb59b7b22e671fbbdb7a70a53a0a919b7ac13a28c6d005652dcaacc6c92fb64",
    
    'ARTIST_DB' : "postgresql://artists:PassArtists@129.152.15.83:5432/PineappleMusic",
    'LISTENER_DB' : "postgresql://listeners:PassListeners@129.152.15.83:5432/PineappleMusic",
    'PREMIUMLISTENER_DB' : "postgresql://premium_listeners:PassPremiumListeners@129.152.15.83:5432/PineappleMusic",
    'GUEST_MANAGER_DB' : "postgresql://guest_manager:PassGuestManager@129.152.15.83:5432/PineappleMusic",
    'DELETE_MANAGER_DB' : "postgresql://delete_manager:PassDeleteManager@129.152.15.83:5432/PineappleMusic"
}